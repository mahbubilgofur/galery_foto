<?php
$lang['upload_no_file_selected'] = 'Anda tidak memilih file untuk diunggah.';
$lang['upload_invalid_filetype'] = 'Format file harus jpg, jpeg, atau png.';
$lang['upload_invalid_filesize'] = 'Ukuran file tidak boleh melebihi 1 MB.';
$lang['upload_file_exceeds_limit'] = 'Berkas yang Anda coba unggah lebih besar dari ukuran yang diizinkan.';
