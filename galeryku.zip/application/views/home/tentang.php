<div class="tnt-cnt">
    <div class="content-tnt">
        <div class="cnt-batas">
            <h1>Selamat Datang di BOBBYPixel!</h1>
            <h3>Jelajahi dan Temukan Keindahan dalam Setiap Pixel di BOBBYPixel!</h3>
            <p>Di BOBBYPixel, kami mengundang Anda untuk memasuki dunia di mana setiap momen menjadi titik awal keindahan pixel. Seiring Anda menjelajahi setiap foto, Anda akan menemukan bahwa setiap pixel adalah portal ke pengalaman visual yang unik.</p>
            <p>Tidak hanya sekadar gambar, di sini setiap pixel menceritakan kisah yang tak terduga. Temukan keindahan dalam detail kecil, dan biarkan setiap pixel menjadi lapisan kreatif yang memperkuat momen-momen berharga Anda.</p>
            <p>Dengan antarmuka yang sederhana dan ramah, BOBBYPixel memberikan Anda ruang untuk mengekspresikan kreativitas Anda melalui setiap foto yang Anda bagikan. Setiap pixel adalah pensil digital Anda untuk menciptakan lukisan visual dari pengalaman hidup Anda.</p>
            <p>Jadi, mari bergabung dalam petualangan pixelasi di BOBBYPixel, di mana setiap like dan komentar menjadi bukti apresiasi untuk keindahan yang Anda temukan dalam setiap pixel. Selamat datang, dan bersama-sama kita temukan keunikan dan keindahan dalam setiap momen pixel di BOBBYPixel!</p>
        </div>
    </div>
</div>
</body>

</html>